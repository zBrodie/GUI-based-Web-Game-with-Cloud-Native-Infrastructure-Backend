export const boardSpots = [


]