import { TurnOrder } from "boardgame.io/core";

function setEvent(img, desc) {
    console.log("WORKS")

    //hides the confirm button from displaying roll amount, also disables and hides the roll amount text
    document.getElementById("confirmButton").setAttribute("disabled", true)
    document.getElementById("confirmButton").style.visibility = "hidden"
    document.getElementById("rollVal").style.visibility = "hidden"

    //creates the tags for events
    let eventPic = document.createElement("img")
    eventPic.setAttribute("class", "gameImg")
    eventPic.src = img

    let eventDesc = document.createElement("span")
    eventDesc.setAttribute("class", "eventDesc")
    eventDesc.innerHTML = desc

    let eventButton = document.createElement("button")
    eventButton.setAttribute("class", "eventButton")
    eventButton.innerHTML = "Confirm"

    //clears the temp div
    document.getElementById("temp").innerHTML = ""
    document.getElementById("temp").append(eventPic);
    document.getElementById("temp").append(eventDesc);
    document.getElementById("temp").append(eventButton);
}

export const UpwardsMobility = {
  setup: () => ({
    players: {
      0: {
        position: 0,
        items: [],
      },
      1: {
        position: 0,
        items: [],
      }
    },
    board: {
        0: { event: 'start',    steps: 0 },
        1: { event: 'advance',  steps: 2 },
        2: { event: 'advance',  steps: 2 },
        3: { event: 'reverse',  steps: -1 },
        4: { event: 'advance',  steps: 3 },
        5: { event: 'advance',  steps: -2 },
        6: { event: 'advance',  steps: 1 },
        7: { event: 'none',     steps: 0 },
        8: { event: 'none',     steps: 0 },
        9: { event: 'reverse',  steps: -2 },
        10: { event: 'none',    steps: 0 },
        11: { event: 'none',    steps: 0 },
        12: { event: 'advance', steps: 2 },
        13: { event: 'advance', steps: 2 },
        14: { event: 'reverse', steps: -1 },
        15: { event: 'advance', steps: 3 },
        16: { event: 'advance', steps: -2 },
        17: { event: 'advance', steps: 1 },
        18: { event: 'advance', steps: 2 },
        19: { event: 'none',    steps: 0 },
        20: { event: 'reverse', steps: -2 },
        21: { event: 'advance', steps: 2 },
        22: { event: 'reverse', steps: -2 },
        23: { event: 'reverse', steps: -2 },
        24: { event: 'win', steps: 0 },
    },
  }),
    turn: {
        minMoves: 1,
        maxMoves: 1,
    },

    // Define the moves for rolling the dice and updating the game state.
    moves: {
      tempRoll: ({G,ctx}) => {
        const die1 = Math.floor(Math.random() * 6) + 1;
        const die2 = Math.floor(Math.random() * 6) + 1;
        let moveDist = die1 + die2;
        // G.players[ctx.currentPlayer].position += moveDist;

        if (G.players[ctx.currentPlayer].position >= 25) {
            ctx.events.endGame({ winner: ctx.currentPlayer });
        }
        const eventCell = G.board[G.players[ctx.currentPlayer].position + moveDist];

        switch (eventCell.event) {
            case 'advance':
                moveDist += eventCell.steps;
                break;
            case 'reverse':
                moveDist -= eventCell.steps;
                break;
            case 'win':
                ctx.events.endGame({ winner: ctx.currentPlayer });
                break;
        }

        G.players[ctx.currentPlayer].position += moveDist;

        // Show all values of current player in console

        console.log("This is board length: " + Object.keys(G.board).length);
        console.log("This is move distance: " + moveDist);
        console.log("This is eventCell.event value: " + eventCell.event);
        console.log("This is eventCell.steps value: " + eventCell.steps);
        console.log("This is current player: " + ctx.currentPlayer);
        console.log("This is current player position: " + G.players[ctx.currentPlayer].position);

        document.getElementById("A_pair_of_strange_dice_lay_bef").style.visibility = "hidden";
        document.getElementById("A_pair_of_strange_dice_lay_bef").setAttribute("disabled", "True");

        document.getElementById("DiceButton").style.visibility = "hidden";
        document.getElementById("DiceButton").setAttribute("disabled", "True");

        document.getElementById("NoPath_-_Copy_8").style.visibility = "hidden";
        document.getElementById("A_pair_of_strange_dice_lay_bef").style.top = "20%";

        let showConfirmButton = document.createElement(`button`);
        showConfirmButton.setAttribute("class", "inGameButton");
        showConfirmButton.setAttribute("id", "confirmButton");
        showConfirmButton.addEventListener("click", setEvent("", ""))
        showConfirmButton.innerHTML = "Show Event";
        showConfirmButton.style.position = "absolute";
        showConfirmButton.style.right = 0;
        showConfirmButton.style.bottom = 0;

        // let showPassButton = document.createElement(`button`);
        // showPassButton.setAttribute("class", "inGameButton");
        // showPassButton.setAttribute("id", "passButton");
        // showPassButton.addEventListener("click", G.moves.tempRoll);
        // showPassButton.innerHTML = "Pass Event";
        // showPassButton.style.position = "absolute";

        let showRollVal = document.createElement("span");
        showRollVal.setAttribute("class", "inGameText");
        showRollVal.setAttribute("id", "rollVal");
        // showRollVal.innerHTML = "Player 1 rolled " + moveDist + "!"
        showRollVal.innerHTML = "Player " + (ctx.currentPlayer) + " rolled " + moveDist + " with an added value of " + eventCell.steps + " from event cell: " + eventCell.event + " !";

        let testDiv = document.createElement("div");
        testDiv.setAttribute("class", "tempDiv");
        testDiv.setAttribute("id", "temp");

        testDiv.appendChild(showRollVal);
        testDiv.appendChild(showConfirmButton);
        // testDiv.appendChild(showPassButton);
        document.getElementById("eventScreen").append(testDiv);

      },
    },
}



