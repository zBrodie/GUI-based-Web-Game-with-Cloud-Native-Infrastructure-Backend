import { Client } from 'boardgame.io/react';
import { upwardsmobility } from './Game';
//import { MyBoard } from './board';
import { MyLobby } from './lobby';
import { MyDebug } from './debug';
