export const boardSpots = [


]